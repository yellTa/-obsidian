package burgerput.tinySeleniumProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TinySeleniumProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TinySeleniumProjectApplication.class, args);
	}

}
