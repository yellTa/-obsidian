package burgerput.tinySeleniumProject;

public class Const {

    public static final String DRIVERLOCATION = "C:/Users/bbubb/Desktop/Burgerput/chromeDriver/chromedriver.exe";


}
