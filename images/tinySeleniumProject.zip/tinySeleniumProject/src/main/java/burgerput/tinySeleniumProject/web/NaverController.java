package burgerput.tinySeleniumProject.web;

import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.time.Duration;
import java.time.LocalDateTime;

import static burgerput.tinySeleniumProject.Const.DRIVERLOCATION;


@Slf4j
@ResponseBody
@Controller
public class NaverController {

    @GetMapping("/naver")
    public String naverSelenium() {

        log.info("start Selenium");

        System.setProperty("java.awt.headless", "false");
        try {
//            System.setProperty("webdriver.chrome.driver", DRIVERLOCATION);

            //automatic web driver management through webdrivermanager
            WebDriverManager.chromedriver().setup();

            //remove being controlled option information bar
            ChromeOptions options = new ChromeOptions();
            options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});;
            //서버에서 돌려서 안돼서 추가한 옵션
//            options.addArguments("--no-sandbox");
//            options.addArguments("--headless=new");
//            options.addArguments("--disable-dev-shm-usage");
//            options.addArguments("--single-process");
//            options.addArguments("--remote-allow-origins=*");
//            options.setBinary("/opt/google/chrome/");
            //서버에서 돌려서 어쩌구 옵션 끝


            WebDriver driver = new ChromeDriver(options);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            //==============================Scrape LOGIC START============================

            //GO TO PAGE
            driver.get("https://www.naver.com");

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
            Thread.sleep(3000);
            //no thanks button click
            WebElement search = driver.findElement(By.id("query"));
            search.sendKeys("됐다");
            search.click();

        } catch (StaleElementReferenceException e) {
            log.info("noSuchEletmet = {}", e);

        } catch (Exception e) {
            log.info("Thread.sleep error [{}]", e);
        }

        return "start";
    }
}
